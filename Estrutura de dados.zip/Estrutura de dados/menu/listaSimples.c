#include "listaSimples.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct No {
  char dado[50];
  No *proximo;
} No;

typedef struct ListaSimples {
  No *primeiro; // Ponteiro para o primeiro nó (excluindo o cabeçalho)
  No *ultimo; // Ponteiro para o último nó
} ListaSimples;

ListaSimples *criar_lista() {
  ListaSimples *lista = (ListaSimples *) malloc(sizeof(ListaSimples));
  if (lista == NULL) {
    return NULL; // Falha na alocação de memória
  }
  lista->primeiro = NULL;
  lista->ultimo = NULL;
  return lista;
}


No *inserir_fim(ListaSimples *lista, char* dado) {
  // Alocar memória para o novo nó
  No *novo = (No *) malloc(sizeof(No));
  if (novo == NULL) {
    return NULL; // Falha na alocação de memória
  }
  // Atribuir valor e inicializar ponteiro 'proximo'
  strcpy(novo->dado, dado); 
  novo->proximo = NULL;
  // Inserir o novo nó no início da lista
  if (lista->primeiro == NULL) {
    // Lista vazia: novo nó é o primeiro e último nó
    lista->primeiro = novo;
    lista->ultimo = novo;
  } 
  else {
    // Lista não vazia: novo nó se torna o último nó
    lista->ultimo->proximo = novo;
    lista->ultimo = novo;
  }
  return novo; // Retornar o ponteiro para o nó inserido
}


No *inserir_inicio(ListaSimples *lista, char* dado) {
  // Alocar memória para o novo nó
  No *novo = (No *) malloc(sizeof(No));
  if (novo == NULL) {
    return NULL; // Falha na alocação de memória
  }
  // Atribuir valor e inicializar ponteiro 'proximo'
  strcpy(novo->dado, dado); 
  novo->proximo = NULL;
  // Inserir o novo nó no início da lista
  if (lista->primeiro == NULL) {
    // Lista vazia: novo nó é o primeiro e último nó
    lista->primeiro = novo;
    lista->ultimo = novo;
  } else {
    // Lista não vazia: novo nó se torna o primeiro nó
    novo->proximo = lista->primeiro;
    lista->primeiro = novo;
  }
  return novo; // Retornar o ponteiro para o nó inserido
}

No *inserir_posicao(ListaSimples *lista, char* dado, int posicao){
  No *novo = (No *) malloc(sizeof(No));
  if (novo == NULL) {
    return NULL; // Falha na alocação de memória
  } 
  strcpy(novo->dado, dado); 
  
  if (lista->primeiro == NULL) {
    // Lista vazia: novo nó é o primeiro e último nó
    lista->primeiro = novo;
    lista->ultimo = novo;
    return novo;
  }

  if(posicao<=1){
    //se escolher colocar no inicio;
    novo->proximo = lista->primeiro;
    lista->primeiro = novo;
    return novo;
  }


  No *atual= lista->primeiro;
  int posicao_atual = 1;
  while(posicao_atual!=posicao-1 && atual->proximo != NULL){
    //procura o antecessor da posição que quer inserir, mas se achar o ultimo da  lista insere no fim
    atual = atual->proximo;
    posicao_atual++;
  }
  if(atual->proximo == NULL && posicao_atual != posicao-1){
    // Inserir no final
    atual->proximo = novo;
    lista->ultimo = novo;
  } else {
    // Inserir no meio
    novo->proximo = atual->proximo;
    atual->proximo = novo;
  }
  return novo;
}

char* remover_inicio(ListaSimples *lista) {
    if (lista->primeiro == NULL) {
    char *valor_removido = malloc(11*sizeof(char));
    if (valor_removido == NULL){
      return NULL;
    } 
    valor_removido= "Lista vazia";
        return valor_removido; // Lista vazia
    }

    No *removido = lista->primeiro;

    // Copiar o valor antes de liberar o nó
    char *valor_removido = malloc(strlen(removido->dado) + 1);
    if (valor_removido == NULL){
      return NULL;
    } 
    strcpy(valor_removido, removido->dado);

    // Atualizar ponteiros da lista
    if (lista->primeiro == lista->ultimo) {
        lista->primeiro = NULL;
        lista->ultimo = NULL;
    } else {
        lista->primeiro = removido->proximo;
    }

    free(removido);  // Liberar o nó

    return valor_removido;  // Retornar a string copiada
}

char* remover_fim(ListaSimples *lista) {
  if (lista->primeiro == NULL) {
    return NULL; // Lista vazia
  }
  No *removido = lista->ultimo;
  char* valor_removido = removido->dado;
  if (lista->primeiro == lista->ultimo) {
    // Único nó: lista fica vazia
    lista->primeiro = NULL;
    lista->ultimo = NULL;
  } else {
    // Vários nós: atualizar ponteiros
    No *atual = lista->primeiro;
    while (atual->proximo != lista->ultimo) {
      atual = atual->proximo;
    }
    // Atualizar o ponteiro do penúltimo nó
    atual->proximo = NULL;
    lista->ultimo = atual;
  }
  
  free(removido);

  return valor_removido;
}

char* remover_posicao(ListaSimples *lista, int posicao){
    if (lista->primeiro == NULL) {
    return NULL; // Lista vazia
  }
  No *atual = lista->primeiro;
  int posicao_atual =1;
  if(posicao<=1){
    No *removido= lista->primeiro;
    char* valor_removido = removido->dado;
    lista->primeiro = removido->proximo;
    free(removido);
    return valor_removido;
  }
  while(posicao_atual!=posicao-1 && atual->proximo->proximo != NULL){
    atual = atual->proximo;
    posicao_atual++;
  }
  if(posicao_atual==posicao-1){
    No *removido= atual->proximo;
    char* valor_removido= removido->dado;
    atual->proximo = removido->proximo;
    free(removido);
    return valor_removido;
  }
  else{
    No *removido= atual->proximo;
    char* valor_removido= removido->dado;
    atual->proximo = NULL;
    lista->ultimo = atual;
    free(removido);
    return valor_removido;
  }
}

No *buscar(ListaSimples *lista, char* dado) {
  if (lista->primeiro == NULL) {
    printf("Lista vazia!\n");
    return NULL; // Lista vazia
  }
  No *atual = lista->primeiro;
  int posicao_atual = 1;
  while(atual->dado != dado && atual->proximo != NULL){
    atual= atual->proximo;
    posicao_atual++;
  }
  if(atual->dado == dado){
    printf("Valor encontrado na posição %d\n", posicao_atual);
    return atual;
  }
  else{
    printf("Valor não encontrado!\n");
    return NULL;
  }
}

void imprimir_lista(ListaSimples *lista) {
  if (lista->primeiro == NULL) {
    printf("Lista vazia!\n");
    return;
  }
  No *atual = lista->primeiro;
  while (atual != NULL) {
    printf("%s ", atual->dado);
    atual = atual->proximo;
  }
  printf("\n");
}

void destruir_lista(ListaSimples *lista) {
  if (lista->primeiro == NULL) {
    return;
  }
  No *atual = lista->primeiro;
  No *anterior;
  while (atual != NULL) {
    anterior = atual;
    atual = atual->proximo;
    free(anterior);
  }
  lista->primeiro = NULL;
  lista->ultimo = NULL;
}
