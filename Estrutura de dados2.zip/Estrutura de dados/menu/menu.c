#include <stdio.h>
#include <unistd.h>
#include <conio.h>
#include <locale.h>
#include <windows.h>
#include "listaSimples.h"
#include "tad_configs.h"
int menu() {

    system("chcp 65001 > NUL");
    printf("1. Inserir nome\n2. Simular\n3.Chamar proximo\n4. Aguardar\n5. Ler\n6. Terminar\n0. Sair\n");
    printf("Informe a opção desejada: ");
    int aux=7;
    int digitou_certo = scanf(" %d", &aux);
    while (aux < 0 || aux>6 || digitou_certo != 1 ){
        int c;
            while ((c = getchar()) != '\n' && c != EOF);// Limpa o buffer
        printf("Opção inválida! Digite novamente: ");
        digitou_certo = scanf(" %d", &aux);
    }
    return aux;
}
int main() {
  TadConfigs *tad_configs;
  int op;
  // Criar TAD e abrir arquivo
  tad_configs = configs_inicializar();
  if (!tad_configs) {
    printf("Erro ao criar TAD\n");
    return 1;
  }
   ListaSimples *minhaLista = criar_lista();
   char nome[50];
  do {
      op = menu();
      switch(op) {
           case 1:{
             //inserir nome
             printf("Digite o nome a ser inserido:");
 
             scanf("%s", nome);
             inserir_fim(minhaLista, nome);
             printf("Nome %s inserido\n", nome);
             break;
           }
          case 2: {
             int aux=1;

            do {

             char *proximo = remover_inicio(minhaLista);
             configs_inserir_nome(tad_configs, proximo);
             configs_atualizar(tad_configs, CHAMAR_PROXIMO, 1);
             free(proximo);
             if(aux==1){
             printf("Presione uma tecla para parar\n");
             }

             sleep(4);
             aux = _kbhit();

             } while(!aux);
             configs_atualizar(tad_configs, AGUARDAR, 1);
              break;
          }
          case 4: {
              configs_atualizar(tad_configs, AGUARDAR, 1);
              break;
          }
          case 3: {
              // Chamar próximo
              char *proximo = remover_inicio(minhaLista);
              configs_inserir_nome(tad_configs, proximo);
              configs_atualizar(tad_configs, CHAMAR_PROXIMO, 1);
              free(proximo);
              break;
          }
          case 6: {
              configs_atualizar(tad_configs, TERMINAR, 1);
              break;
          }
          case 5: {
              // Carregar configurações
              configs_ler(tad_configs);
              // Exibir configurações (carrega do arquivo existente se existir)
              configs_mostrar(tad_configs);
              break;
          }
          case 0: {
              configs_destruir(tad_configs);
              destruir_lista(minhaLista);
              printf("Até a próxima!\n");
              break;
          }
          default: {
              printf("Opção inválida!\n");
                break;
          }
      }
  } while (op != 0);
  return 0;
}
